import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrl: './hosegriado.component.css'
})
export class HosegriadoComponent {
  elso!: number;
  masodik!: number;
  harmadik!: number;
  allapot: string[] = [];

  AllapotMentes() {
    if(this.elso && this.masodik && this.harmadik){
    const aktualisRiadoSzint = this.aktualisRiadoSzint();
    this.allapot.push(`${this.elso}, ${this.masodik} és ${this.harmadik} esetén ${aktualisRiadoSzint} hőségriadó volt elrendelve`);
    this.elso = null!;
    this.masodik = null!;
    this.harmadik = null!;
  }
  else{
    alert("Minden mezőt ki kell tölteni a mentéshez!");
  }
  }


  aktualisRiadoSzint(){
    if (this.elso >=  27 && this.masodik >= 27 && this.harmadik >= 27) {
      return '3. szintű';
    }
    else if (this.elso >= 25 && this.masodik >= 25 && this.harmadik >= 25) {
      return '2. szintű';
    }
    else if (this.elso >= 25 || this.masodik >= 25 || this.harmadik >= 25) {
      return '1. szintű';
    }
    else{
      return '0. szintű';
    }
    
  }

}