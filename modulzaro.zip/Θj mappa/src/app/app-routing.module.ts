import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HosegriadoComponent } from './hosegriado/hosegriado.component';
import { KekturaComponent } from './kektura/kektura.component';
import { Hiba404Component } from './hiba404/hiba404.component';

const routes: Routes = [
  {path:"hosegriado",component:HosegriadoComponent},
  {path:"kektura",component:KekturaComponent},
  {path:"hiba404",component:Hiba404Component},
  {path:"", redirectTo:"/hosegriado",pathMatch:"full"},
  {path:"**",component:Hiba404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 


}
